//
//  YJWScrollViewCell.h
//  YJWCycleScrollView
//
//  Created by apple on 2016/11/29.
//  Copyright © 2016年 apple. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "YJWScrollModel.h"

@interface YJWScrollViewCell : UICollectionViewCell

@property (nonatomic, strong) YJWScrollModel *model;

@end
