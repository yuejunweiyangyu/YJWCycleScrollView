//
//  YJWScrollViewCell.m
//  YJWCycleScrollView
//
//  Created by apple on 2016/11/29.
//  Copyright © 2016年 apple. All rights reserved.
//

#import "YJWScrollViewCell.h"
#import "UIImageView+WebCache.h"
#import "YJWConst.h"

@implementation YJWScrollViewCell{
    UIImageView *imageView;
}

- (instancetype)initWithFrame:(CGRect)frame{
    if (self = [super initWithFrame:frame]) {
        self.contentView.backgroundColor = [UIColor whiteColor];
        UIImageView *image = [[UIImageView alloc] init];
        [self.contentView addSubview:image];
        imageView = image;
    }
    return self;
}

- (void)setModel:(YJWScrollModel *)model{
    _model = model;
    [imageView sd_setImageWithURL:[NSURL URLWithString:model.imageUrl] placeholderImage:[UIImage imageNamed:PLACEHOLD_IMAGE]];
}

- (void)layoutSubviews{
    [super layoutSubviews];
    imageView.frame = self.bounds;
}

@end
