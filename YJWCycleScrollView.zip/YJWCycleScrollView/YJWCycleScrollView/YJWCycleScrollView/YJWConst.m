//
//  YJWConst.m
//  YJWCycleScrollView
//
//  Created by apple on 2016/11/29.
//  Copyright © 2016年 apple. All rights reserved.
//

#import <UIKit/UIKit.h>

const CGFloat PAGECONTROL_WIDTH = 200.0f;

const CGFloat IMAGE_GROUP  = 200.0f;

NSString * const PLACEHOLD_IMAGE = @"";
