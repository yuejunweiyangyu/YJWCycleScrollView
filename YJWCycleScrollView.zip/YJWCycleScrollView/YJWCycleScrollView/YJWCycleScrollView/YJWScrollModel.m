//
//  YJWScrollModel.m
//  YJWCycleScrollView
//
//  Created by apple on 2016/11/29.
//  Copyright © 2016年 apple. All rights reserved.
//

#import "YJWScrollModel.h"

@implementation YJWScrollModel

- (void)setValue:(id)value forUndefinedKey:(NSString *)key{
    
}

@end
