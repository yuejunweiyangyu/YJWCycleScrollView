//
//  YJWConst.h
//  YJWCycleScrollView
//
//  Created by apple on 2016/11/29.
//  Copyright © 2016年 apple. All rights reserved.
//

#import <UIKit/UIKit.h>

/* pagecontrol的宽度 */
UIKIT_EXTERN const CGFloat PAGECONTROL_WIDTH;
/* 图片组数 */
UIKIT_EXTERN const CGFloat IMAGE_GROUP;
/* 图片默认图 */
UIKIT_EXTERN NSString *const PLACEHOLD_IMAGE;
