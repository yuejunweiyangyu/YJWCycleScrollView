//
//  YJWCycleScrollView.m
//  YJWCycleScrollView
//
//  Created by apple on 2016/11/29.
//  Copyright © 2016年 apple. All rights reserved.
//

#import "YJWCycleScrollView.h"
#import "YJWScrollViewCell.h"
#import "YJWScrollModel.h"
#import "YJWConst.h"

#define cellID  @"YJWScrollViewCell"
#define viewHeight  CGRectGetHeight(self.bounds)
#define viewWidth   CGRectGetWidth(self.bounds)
@interface YJWCycleScrollView()<UICollectionViewDelegate,UICollectionViewDataSource,UIScrollViewDelegate>{
    UICollectionView *_collectionView;
    UIPageControl *_pageControl;
}
/* 是否隐藏pagecontrol,默认不隐藏 */
@property (nonatomic, assign) BOOL pagecontrolHide;

/* 只有一张图是否隐藏pagecontrol,默认隐藏 */
@property (nonatomic, assign) BOOL onlyPagecontrolHide;

/* pagecontrol选中颜色 */
@property (nonatomic, strong) UIColor *pagecontrolSelectedColor;

/* pageControl未选中颜色 */
@property (nonatomic, strong) UIColor *pagecontrolNormalColor;

/* 数据源 */
@property (nonatomic, strong) NSMutableArray *imageArr;

/* 数组个数 */
@property (nonatomic, assign) NSInteger imageNum;

/* 是否循环滚动 */
@property (nonatomic, assign) BOOL isCycleSlide;

/* 滚动时长，默认为2妙 */
@property (nonatomic, assign) NSInteger cycleTime;

/* 是否定时滚动，默认滚动，如果要在cell中显示请将此设置为no */
@property (nonatomic, assign) BOOL isAutoScroll;

/* 计时器 */
@property (nonatomic, strong) NSTimer *timer;

@end

@implementation YJWCycleScrollView

- (instancetype)initWithFrame:(CGRect)frame{
    if (self = [super initWithFrame:frame]) {
        [self loadSomeConfigur];
        [self customSubViews];
    }
    return self;
}
- (void)awakeFromNib{
    [super awakeFromNib];
    [self loadSomeConfigur];
    [self customSubViews];
}

- (void)loadSomeConfigur{
    self.pagecontrolHide = NO;
    self.onlyPagecontrolHide = YES;
    self.isAutoScroll = YES;
    self.cycleTime = 3.0f;
    self.isCycleSlide = YES;
    self.pagecontrolNormalColor = [UIColor whiteColor];
    self.pagecontrolSelectedColor = [UIColor redColor];
}
- (void)customSubViews{
    UICollectionViewFlowLayout *flowLayout = [[UICollectionViewFlowLayout alloc] init];
    flowLayout.minimumLineSpacing = 0;
    flowLayout.minimumInteritemSpacing = 0;
    flowLayout.itemSize = CGSizeMake(viewWidth, viewHeight);
    flowLayout.scrollDirection = UICollectionViewScrollDirectionHorizontal;
    
    UICollectionView *collectionView = [[UICollectionView alloc] initWithFrame:self.bounds collectionViewLayout:flowLayout];
    collectionView.delegate = self;
    collectionView.dataSource = self;
    collectionView.pagingEnabled = YES;
    collectionView.showsHorizontalScrollIndicator = NO;
    [collectionView registerClass:[YJWScrollViewCell class] forCellWithReuseIdentifier:cellID];
    collectionView.scrollsToTop = NO;
    [self addSubview:collectionView];
    _collectionView = collectionView;
    
}

- (void)setImageGroup:(NSArray *)imageGroup{
    for (NSString *imageUrl in imageGroup) {
        YJWScrollModel *model = [[YJWScrollModel alloc] init];
        model.imageUrl = imageUrl;
        [self.imageArr addObject:model];
    }
    self.imageNum = self.imageArr.count;
    [self addPageControl];
    
}

- (void)addPageControl{
    if (self.pagecontrolHide) return;
    if (self.imageArr.count == 1) {
        _collectionView.scrollEnabled = NO;
        if (self.onlyPagecontrolHide) return;
    }else{
        _collectionView.scrollEnabled = YES;
        UIPageControl *pagecontrol = [[UIPageControl alloc] initWithFrame:CGRectMake(viewWidth / 2 - PAGECONTROL_WIDTH / 2, viewHeight - 10, PAGECONTROL_WIDTH, 2)];
        pagecontrol.numberOfPages = self.imageArr.count;
        pagecontrol.currentPageIndicatorTintColor = self.pagecontrolSelectedColor;
        pagecontrol.pageIndicatorTintColor = self.pagecontrolNormalColor;
        [self addSubview:pagecontrol];
        _pageControl = pagecontrol;
    }
    [_collectionView reloadData];
    if (self.isCycleSlide) {
        [_collectionView setContentOffset:CGPointMake(self.imageNum * IMAGE_GROUP * 0.5 * viewWidth, 0) animated:NO];
    }
    [self startTime];
}
- (void)startTime{
    if (self.isAutoScroll) {
        if (self.isCycleSlide) {
            [self.timer fire];
        }
    }
}
- (void)cycleScrollRepeat{
    int content_x = (int)_collectionView.contentOffset.x;
    int remain = (int)fmod(content_x, (int)viewWidth);
    int index = 0;
    if (remain >= (int)viewWidth / 2 || remain == 0) {
        index = content_x / (int)viewWidth + 1;
    }else{
        index = content_x / (int)viewWidth;
    }
    [_collectionView setContentOffset:CGPointMake(index * viewWidth, 0) animated:YES];
}

#pragma  mark   ==========================代理方法==============================

- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section{
    return self.isCycleSlide ? self.imageArr.count * IMAGE_GROUP : self.imageArr.count;
}
- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath{
    NSInteger index = fmod(indexPath.row, self.imageNum);
    YJWScrollModel *model = self.imageArr[index];
    YJWScrollViewCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:cellID forIndexPath:indexPath];
    cell.model = model;
    return cell;
}
- (void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath{
    NSInteger index = fmod(indexPath.row, self.imageNum);
    if (self.clickBlock) {
        self.clickBlock(index);
    }
}

- (void)scrollViewWillBeginDragging:(UIScrollView *)scrollView{
    if (_timer) {
        [self.timer setFireDate:[NSDate distantFuture]];
    }
}
- (void)scrollViewDidEndDragging:(UIScrollView *)scrollView willDecelerate:(BOOL)decelerate{
    if (_timer) {
        [self.timer setFireDate:[NSDate distantPast]];
    }
}

- (void)scrollViewDidScroll:(UIScrollView *)scrollView{
    NSInteger index = fmod((scrollView.contentOffset.x / viewWidth), self.imageNum);
    _pageControl.currentPage = index;
}


#pragma mark   =============================懒加载==================================
- (NSMutableArray *)imageArr{
    if (!_imageArr) {
        _imageArr = [[NSMutableArray alloc] init];
    }
    return _imageArr;
}

- (NSTimer *)timer{
    if (!_timer) {
        _timer = [NSTimer scheduledTimerWithTimeInterval:self.cycleTime target:self selector:@selector(cycleScrollRepeat) userInfo:nil repeats:YES];
        [[NSRunLoop mainRunLoop] addTimer:_timer forMode:NSRunLoopCommonModes];
    }
    return _timer;
}

- (void)dealloc{
    if (_timer) {
        _timer = nil;
        [_timer invalidate];
    }
}

@end
