//
//  YJWScrollModel.h
//  YJWCycleScrollView
//
//  Created by apple on 2016/11/29.
//  Copyright © 2016年 apple. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface YJWScrollModel : NSObject

@property (nonatomic, strong) NSString *imageUrl;

@end
