//
//  ViewController.m
//  YJWCycleScrollView
//
//  Created by apple on 2016/11/29.
//  Copyright © 2016年 apple. All rights reserved.
//

#import "ViewController.h"
#import "YJWCycleScrollView.h"

@interface ViewController ()

@property (nonatomic, strong) YJWCycleScrollView *scrollView;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self.view addSubview:self.scrollView];
    self.scrollView.imageGroup = @[@"http://www.58hyj.com/upload/ad/20161014/20161014114025739.jpg",@"http://www.58hyj.com/upload/ad/20161014/20161014113905133.jpg"];
}

- (YJWCycleScrollView *)scrollView{
    if (!_scrollView) {
        _scrollView = [[YJWCycleScrollView alloc] initWithFrame:CGRectMake(0, 0, 375, 200)];
    }
    return _scrollView;
}


@end
