//
//  YJWCycleScrollView.h
//  YJWCycleScrollView
//
//  Created by apple on 2016/11/29.
//  Copyright © 2016年 apple. All rights reserved.
//

#import <UIKit/UIKit.h>

typedef void(^clickBlock)(NSInteger index);
@interface YJWCycleScrollView : UIView
/* 图片数组 */
@property (nonatomic, strong) NSArray *imageGroup;

@property (nonatomic, copy) clickBlock clickBlock;

@end
